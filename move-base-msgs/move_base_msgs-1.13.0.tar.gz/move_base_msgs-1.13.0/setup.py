from setuptools import find_packages, setup
setup(name='move_base_msgs', version='1.13.0', packages=find_packages(),
      install_requires=['genpy'])