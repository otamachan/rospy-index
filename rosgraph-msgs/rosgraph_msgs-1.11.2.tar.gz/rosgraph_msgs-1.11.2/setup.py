from setuptools import find_packages, setup
setup(name='rosgraph_msgs', version='1.11.2', packages=find_packages(),
      install_requires=['genpy'])