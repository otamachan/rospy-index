from setuptools import find_packages, setup
setup(name='shape_msgs', version='1.12.7', packages=find_packages(),
      install_requires=['genpy'])