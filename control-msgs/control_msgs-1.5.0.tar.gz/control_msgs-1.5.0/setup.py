from setuptools import find_packages, setup
setup(name='control_msgs', version='1.5.0', packages=find_packages(),
      install_requires=['genpy'])